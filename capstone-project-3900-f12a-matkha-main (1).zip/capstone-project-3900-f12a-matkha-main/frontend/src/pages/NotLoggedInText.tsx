function NotLoggedInText() {
  return (
    <div style={{ textAlign: 'center', color: 'red' }}>
      <p>You need to be logged in to access this tab.</p>
    </div>
  );
}

export default NotLoggedInText;
