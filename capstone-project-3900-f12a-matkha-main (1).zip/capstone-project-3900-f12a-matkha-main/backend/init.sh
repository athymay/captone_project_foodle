#!/bin/bash

pip3 install pymongo fastapi "uvicorn[standard]" requests beautifulsoup4 "python-jose[cryptography]" "passlib[bcrypt]" python-multipart apscheduler "pymongo[srv]"
